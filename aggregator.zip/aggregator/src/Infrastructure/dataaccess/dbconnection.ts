

var sql =  require("mssql");

    // config for your database
    const config = {
      user: 'sa',
      password: 'Aggregator1',
      server: 'localhost', // You can use 'localhost\\instance' to connect to named instance
      database: 'Aggregator',
   
      options: {
          encrypt: true // Use this if you're on Windows Azure
      }
  }

    sql.connect(config, function (err) {
      if(err)
      console.log(err);
      else
      console.log("connected");
    });
